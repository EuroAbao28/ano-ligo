import { Routes, Route } from 'react-router'
import Home from './pages/Home'
import GamePage from './pages/GamePage'
import ComingSoon from './pages/ComingSoon'
import ImpostorGame from './pages/games/ImpostorGame'

function App () {
  return (
    <Routes>
      <Route path='/' element={<Home />} />
      <Route path='/game/:id' element={<GamePage />}>
        <Route index element={<ComingSoon />} />
        <Route path='play' element={<ImpostorGame />} />
      </Route>
    </Routes>
  )
}

export default App
