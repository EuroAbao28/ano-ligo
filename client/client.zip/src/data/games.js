export const games = [
  {
    id: '1',
    title: 'Impostor',
    description: 'Find the spy before they fool you all.',
    emoji: '🕵️',
    tag: 'Strategy',
    players: '4P+',
    color: 'from-red-600 to-zinc-800',
    implemented: true
  }
  // add more games here later...
]
